import pandas as pd
import csv
import np
import re
import os
import openpyxl
import treelib
from treelib import Tree
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()

print('Open Excel file...\n')

file_path = filedialog.askopenfilename(filetypes=[("Excel files", ".xlsx .xls")])

# STEP ONE: PRE_PROCESSING OF INPUT FILE
pd.set_option('display.max_columns',
              None)  # expands output view to display more columns

# read our Excel input file
xlsx = pd.ExcelFile(file_path)
tab_1 = pd.read_excel(xlsx, 'Demographics NCI')
tab_2 = pd.read_excel(xlsx, 'NCIt Concept Code and Lineage')

# convert files to CSV UTF-8
tab_1.to_csv('Demographics NCI.csv', encoding = 'utf-8', index = False)

tab_2.to_csv('NCIt Concept Code and Lineage.csv',
             encoding = 'utf-8',
             index = False)

# drop cols 2 thru 8 in tab_1 file
tab_1v2 = tab_1.drop(tab_1.iloc[:, 2:8], axis = 1)

# drops first col
del tab_1v2[tab_1v2.columns[0]]

# replaces * in first col
tab_1v2['CDE Name'] = tab_1v2['CDE Name'].apply(lambda x: x.replace('*', ''))

# assign column headers as list to variable
subset_list = tab_1v2.columns.tolist()

unique = tab_1v2.drop_duplicates(
subset = subset_list, keep = 'first').reset_index(drop = True)  # reads our final table while dropping our duplicates

unique.to_csv('Unique.csv', index = False)

# stratify by delimiter '>' into distinct cols
input_file = unique['NCIt Concept Lineage'].apply(
  lambda x: pd.Series(str(x).split(">")))

file_copy = input_file.copy()

# renames every Level column by creating a dict then assigning it for renaming
d = dict(zip(file_copy.columns,[f'level_{i+1}'.format(i) for i in range(len(file_copy.columns))]))

file_copy_v2 = file_copy.rename(columns = d)

file_copy_v2.to_csv('File_Copy.csv', index = False)

col_headers = file_copy_v2.columns.tolist()

# copies our CDE col to a new df
cde_file = unique['CDE Name'].copy()

# clean file
chars_to_remove = ['(', ')']
regular_expression = '[' + re.escape(''.join(chars_to_remove)) + ']'

# splits all columns throughout the dataframe by chars
split_file = [input_file[col].str.split(pat = regular_expression, expand = True).add_prefix(col) for col in input_file.columns]

# print(split_file)
scrubbed_file = pd.concat(split_file, axis = 1)

# removes every third column
scrubbed_filev2 = scrubbed_file.loc[:, (np.arange(len(scrubbed_file.columns)) + 1) %3 != 0]

# inserts new ID col for auto incrementing in CDE file
df = pd.DataFrame(cde_file)

df.insert(1, 'ID', '')

# auto increments ID to assign keys
ids = range(0, 0 + len(df))

# for loop iterates through all rows to assign key until the end of the dataframe
for id in ids:
  df.loc[id, 'ID'] = id + 1

# rejoining our CDE file back to the original file
clean_file = pd.concat([scrubbed_filev2,df],axis=1)

clean_file.to_csv('Clean_File.csv', encoding = 'utf-8', index = False)

# renames every Level column by creating a dict then assigning it for renaming
d_1 = dict(zip(clean_file.columns[0::2],[f'level_{i+1}'.format(i) for i in range(len(clean_file.columns[0::2]))]))

file = clean_file.rename(columns = d_1)

# renames every other ID column by creating a dict then assigning it for renaming
d_2 = dict(zip(file.columns[1::2],[f'ID_{i+1}'.format(i) for i in range(len(file.columns[1::2]))]))

file_2 = file.rename(columns = d_2)

file_2[col_headers] = file_copy_v2[col_headers]

file_2.to_csv('test.csv', index = False)

# moves all data left by taking over np.nan cells which are then moved to end --correctly represents hierarchy in csv format
final_file = file_2.apply(lambda row: pd.Series(sorted(row.tolist(), key = lambda x: np.isnan(x) if isinstance(x, float) else 0),index = row.index), axis = 1)

final_file.to_csv('NCIConceptLineage.csv', encoding = "utf-8", index = False)

# STEP TWO: INPUT FILE -> TREE METHODOLOGY
def create_tree(df, items, parent, root = None, tree = None, i=0):
  #Create a tree from a dataframe
  if tree is None:
    tree = Tree()
    root = root if root else parent
    tree.create_node(root, parent)
  i = i + 1

  for parental, group_df in df.groupby(items[i - 1]):
    tree.create_node(parental[0], parental[1], parent=parent)
    if i <= len(items) - 1:
      create_tree(group_df, items, parental[1], tree=tree, i=i)
  return tree

# creates a list of the headers
header_list = final_file.columns.tolist()

# puts the list of headers into a nested list by pairs (concept, ID)
my_list = [header_list[i:i + 2] for i in range(0, len(header_list), 2)]

# intiates items as my_list
items = my_list

# intiates variable for length of dataframe
df_len = len(final_file)

# initiates tree variable from final_file
tree = create_tree(final_file.head(df_len), items, 'concepts', 'NCI Concept')

tree.show()

# check whether the file exists, otherwise create a text file (save2file appends the tree to the text file everytime the code is run --the if statement below ensures that the tree only appears in the text file once regardless of how many times the code is run)
if not os.path.exists('tree.txt'):
  tree.save2file('tree.txt')
#EOF
